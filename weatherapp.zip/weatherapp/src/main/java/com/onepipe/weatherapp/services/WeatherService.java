package com.onepipe.weatherapp.services;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.exc.StreamWriteException;
import com.fasterxml.jackson.databind.*;
import com.fasterxml.jackson.dataformat.xml.XmlMapper;
import com.fasterxml.jackson.dataformat.xml.ser.ToXmlGenerator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestClientException;
import org.springframework.web.client.RestTemplate;
import org.springframework.web.server.ServerErrorException;
import org.springframework.web.util.UriComponents;
import org.springframework.web.util.UriComponentsBuilder;

import java.io.IOException;
import java.io.StringWriter;
import java.net.URI;

@Service
public class WeatherService {

    @Autowired
    RestTemplate restTemplate;

    @Value("${api.key}")
    private String apiKey;

    public String fetchCity(String city) {

        URI url = UriComponentsBuilder.fromHttpUrl("http://api.openweathermap.org/data/2.5/weather")
                .queryParam("q", city)
                .queryParam("appid", apiKey)
                .build().toUri();

        try {
            ResponseEntity<String> response = restTemplate.exchange(url, HttpMethod.GET, null, String.class);
            if (response.getStatusCode().is2xxSuccessful()) {
                System.out.println(toXml(response.getBody(), "Weather"));
                return response.getBody();
            }
            return null;
        } catch (RestClientException exception) {
            exception.printStackTrace();
            throw exception;
        }
    }

    private String toXml(String json, String rootName) {
        ObjectMapper jsonMapper = new ObjectMapper();
        try {
            JsonNode jsonNode = jsonMapper.readValue(json, JsonNode.class);
            XmlMapper xmlMapper = new XmlMapper();
            xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_DECLARATION, true);
            xmlMapper.configure(ToXmlGenerator.Feature.WRITE_XML_1_1, true);
            xmlMapper.configure(SerializationFeature.INDENT_OUTPUT, true);
            ObjectWriter ow = xmlMapper.writer().withRootName(rootName);
            StringWriter sw = new StringWriter();
            ow.writeValue(sw, jsonNode);
            String xml = sw.toString();
            return xml;
        } catch (StreamWriteException e) {
            e.printStackTrace();
        } catch (DatabindException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
        return null;
    }

}
